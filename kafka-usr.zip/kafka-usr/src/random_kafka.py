import random
import pickle

ans = []


def random_key():
    a = random.randint(97, 122)
    return chr(a)


def random_value():
    a = random.randint(0, 10)
    return str(a)


def generate_list():
    dict_num = random.randint(5, 26)
    mid = {}
    for i in range(dict_num):
        if random_key() in mid:
            continue
        else:
            mid[random_key()] = random_value()
    ans.append(mid)


def txt_save():
    with open("1.txt", 'w') as f:
        for i in range(len(ans)):
            for key, value in ans[i].items():
                f.write(key + ':' + value + ',')
            f.write('\r')


if __name__ == '__main__':
    for i in range(50000):
        generate_list()
    print(ans)
    path = './1'
    f = open(path, 'wb+')
    pickle.dump(ans,f)
    f.close()

    f=open(path,'rb')
    res = pickle.load(f)
    print(res)
    #txt_save()
