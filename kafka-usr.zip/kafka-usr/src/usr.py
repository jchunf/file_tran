import json

from Graph import Node, LogNode, IndicatorNode, Edge, Graph
import pickle


class Parser:

    def __init__(self):
        pass

    def line_processor(self, d):
        nodes = list()

        # LogNode
        logNode_name = 'log' + '=' + str(d)
        if logNode_name in Node.node_mapped:
            logNode = Node.node_mapped[logNode_name]
        else:
            logNode = LogNode(logNode_name)
        nodes.append(logNode)

        for key in d:
            indicatorNode_name = str(key) + '=' + str(d[key])
            if indicatorNode_name in Node.node_mapped:
                indicatorNode = Node.node_mapped[indicatorNode_name]
            else:
                indicatorNode = IndicatorNode(indicatorNode_name)
            indicatorNode.add_edge(logNode)
            nodes.append(indicatorNode)

        return nodes

    def query(self, node: Node):
        return node.connect_edges


if __name__ == '__main__':
    path = './node_pickle'
    f = open(path, 'rb')
    value=pickle.load(f)
    Node.node_mapped = value
    for key in Node.node_mapped:
        print(key, Node.node_mapped.get(key))

    value = 'a=3'
    node = Node.node_mapped[value]
    parser = Parser()
    ans = parser.query(node)
    print(value, '连接数为', str(len(ans)), ',如下:')
    #for key in ans:
      # print(node.get_another_node(ans[key]).value)


