# -*- coding: utf-8 -*-
from kafka import KafkaConsumer
import pickle

from usr import Parser, Node

import sys
sys.setrecursionlimit(1000000)


def consumer_demo():
    consumer = KafkaConsumer(
        'test',
        bootstrap_servers='localhost:9092',
        group_id='test'
    )
    sum_iter = 0
    for message in consumer:
        value = message.value.decode('utf-8')
        value = eval(value)
        if not isinstance(value, dict):
            print(value, 'not dict!')
            continue
        print(value)
        parser = Parser()
        parser.line_processor(value)
        sum_iter += 1
        # 先设置每隔1个就保存一次
        if sum_iter % 1 == 0:
            path = './node_pickle'
            f = open(path, 'wb')
            pickle.dump(Node.node_mapped, f)
            f.close()



def random_data_test():
    path = './1'
    f = open(path, 'rb')
    res = pickle.load(f)
    # print(res)
    sum_iter = 0
    for message in res:
        if not isinstance(message, dict):
            print(message, 'not dict!')
            continue
        # print(message)
        parser = Parser()
        parser.line_processor(message)
        sum_iter += 1
        # 先设置每隔1个就保存一次
        if sum_iter % 1000 == 0:
            path = './node_pickle'
            f = open(path, 'wb+')
            pickle.dump(Node.node_mapped, f)
            f.close()


if __name__ == '__main__':
    # consumer_demo()
    random_data_test()
    for key in Node.node_mapped:
        print(key, Node.node_mapped[key])
