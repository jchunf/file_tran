class Edge:
    edge_id = 0
    edge_mapped = dict()

    def __init__(self, start_node, end_node, value):
        self.id = Edge.edge_id
        Edge.edge_id += 1
        self.start_node = start_node
        self.end_node = end_node
        self.value = value
        Edge.edge_mapped[self.id] = (self.start_node, self.end_node)


class Node:
    node_id = 0
    node_mapped = dict()

    def __init__(self):
        self.id = Node.node_id
        Node.node_id += 1
        self.connect_edges = dict()

    def add_edge(self, target_node, value=None):
        edge = Edge(self, target_node, value)
        self.connect_edges[edge.edge_id] = edge
        target_node.connect_edges[edge.edge_id] = edge

    def get_another_node(self, edge: Edge):
        if edge.start_node.id == self.id:
            return edge.end_node
        else:
            return edge.start_node


class LogNode(Node):
    def __init__(self, value):
        super().__init__()
        self.value = value
        Node.node_mapped[value] = self


class IndicatorNode(Node):

    def __init__(self, value):
        super().__init__()
        self.value = value
        Node.node_mapped[value] = self


class Graph:

    def __init__(self):
        """
            struct: {node_id1:Node1,node_id2:Node2...}
        """
        self.nodes = dict()

    def add_one_node(self, node: Node):
        self.nodes[node.id] = node


