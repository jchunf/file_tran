# kafkaUSR

#### 介绍
用于在kafka环境中输入日志信息，Python进行读取消息并构建日志关联图
#### 环境
Python 3.8
